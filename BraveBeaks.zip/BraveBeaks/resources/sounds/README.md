# Sound Files for Angry Birds Clone
## Required Sound Effects

### Bird Sounds
- `bird_launch.wav` - Sound when bird is launched from slingshot

### Block Sounds
- `block_hit.wav` - General block collision sound 

### Enemy Sounds
- `enemy_hit.wav` - Enemy taking damage ======= `enemy_death.wav` - Enemy defeated

### UI Sounds
- `button_click.wav` - Button/menu click
- `level_win.wav` - Level completed successfully
- `level_lose.wav` - Level failed

## Background Music 
- `menu_music.wav` - Main menu background music
- `game_music.wav` - In-game background music (?????????????????????)

## Note
The game will still run without these sound files - it will just print warnings to the console. Sounds are optional but enhance the game experience!
